# KASCH & WHH Performance Dashboard — Website Package

## What's included
- `index.html` — your uploaded dashboard, preserved and renamed to the standard homepage filename used by static website hosts.

## Test it locally
1. Keep `index.html` in this folder.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, or Safari).
3. Check the charts, filters, buttons, and layout on desktop and mobile.

## Publish it free with GitHub Pages
1. Sign in or create an account at https://github.com/
2. Create a new repository. For example: `kasch-whh-dashboard`.
3. Upload `index.html` to the repository's root folder.
4. Open **Settings → Pages**.
5. Under the build/deployment source, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then save.
7. Wait for GitHub Pages to publish the site. The published URL will be shown in the Pages settings.

## Important privacy/security note
This dashboard appears to concern nursing performance and patient compliments. Before publishing it to a public URL, confirm you have authorization and that it contains no confidential operational information, personal data, patient-identifying details, or material that should only be available inside your organization. A public static website should be treated as visible to anyone with the link and potentially searchable. If the dashboard is internal, use your organization's approved private hosting/access controls instead.

## Notes
- The dashboard is a standalone HTML file and includes its chart library in the file, so no separate CSS or JavaScript file is required for the current version.
- This package does not publish the site for you; publishing requires signing in and completing the hosting steps above.
